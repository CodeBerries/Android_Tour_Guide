package com.example.tourguide;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.app.Fragment;
import android.net.Uri;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements TextFragment.OnFragmentInteractionListener, ListFragment.OnFragmentInteractionListener
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    @Override
    public void onFragmentInteraction(int index)
    {
        FragmentManager manager = getSupportFragmentManager();
        TextFragment textFragment = (TextFragment)manager.findFragmentById(R.id.fragmentContainerView2_text);
        textFragment.updateTextView(index);
    }

}